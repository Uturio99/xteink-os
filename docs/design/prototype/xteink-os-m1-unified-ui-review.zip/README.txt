XTEInk OS — M1 Unified UI/UX Collection Review Package
======================================================
Target Device: XTEINK X4 Pro (480x800 Portrait E-Paper)
Milestone: M1 Acceptance Patch (Tasks 1–5 & Fixes P1-A / P1-B Complete)

INSPECTION INSTRUCTIONS:
1. Open 'prototype.html' in Google Chrome, Microsoft Edge, or Safari:
   - Genuine TrueType Noto Serif and Noto Sans fonts are bundled offline in 'fonts/' with SIL Open Font License 1.1 for 100% reproducible typography across all host environments.
   - Use top bar buttons (FR-01 through FR-15) to jump directly between frames.
   - Click 'Journey A' through 'Journey E' to trigger automated user journey playback.
   - In FR-05 (Library), test sorting by 'Gần đây', 'Tên sách (A-Z)' (Vietnamese alphabetical sorting), and 'Tiến độ' (reading progress descending).
   - In FR-06 (Search), test clearing search via '(×)': restores the full 6-book catalogue, updates status to 'Toàn bộ danh mục (6 cuốn)', and retains input focus; try accented ('chiến tranh') and unaccented ('chien tranh') queries to see accurate highlighted relevance.
   - In FR-08 (Reader), press Arrow Left / Arrow Right to turn pages; press Space to toggle HUD (FR-09).
   - In FR-09 (Reader HUD), notice the underlying reading prose remains fully visible and legible under the opaque control bars; tapping the central reading area returns to FR-08.
   - In FR-11 (Typography Settings), observe aligned defaults (19px / 1.65); changing font size, family, line height, or margins updates both FR-08 and FR-09 identically while preserving chapter/page reading state.
   - In the top toolbar, use '[Chế độ: Tệp hợp lệ / Lỗi định dạng]' to toggle FR-13 between valid EPUB and unsupported file fallback.
2. Open 'gallery.html' for a 15-frame contact sheet with reconciled design metadata.
3. Inspect 'captures/' for exact native 480x800 captures and 'captures/binary/' for 1-bit legibility evidence.
4. Read 'specs/UNIFIED_UI_COLLECTION.md' and audit reports in 'audits/' for complete design contracts and QA proof.
